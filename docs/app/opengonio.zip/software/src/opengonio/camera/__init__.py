"""USB camera capture (UVC)."""
